This little daemon app periodically check if P2kdevice is plugged in/out.
You can see the trayicon tooltip, and rightclick menu.
If P2kDevice plugged, P2kCommander starts automatically.
To install it,just make a shortcut to Startmenu/autostart folder.

-------------------------------
New version -------september.8.

Checkmarks to autoswitching to p2kCommander and Autorunning p2kCommander.
This setting stored and non-volatile.
Manual command to set P2kmode. (Setting back to AT mode not yet implemented)
Trayicon colours changes: red==not connected, blue==AT device (modem), gold==P2kdevice


-------------------------------
New version -------september.11.
Balloon tooltip notifications!
-----------------october 10.----integrated to p2kc package

-------------------------------
New version ---------october.15.
restart,flashmode,starting skinner4moto,recognize phone model



Regards and have fun.....s5vi@freemail.hu