If P2kCommander not recognize the phone:
1.) You maybe need Microsoft USB patches.(WindowsXP-KB822603-x86)
2.) Start P2kCommander, get p2kdrive to connect.Devices will be recognized,You just enter the path of p2kdriver.
3.) Make sure the p2kdrivers installed correctly. In device manager you must see Motorola USB Composite devices.

Please download Lister.exe and irfanview to full-featured file viewing.
Lister can cooperate with irfanview.
Irfanview: must be installed and configured.
Lister.exe: just copy P2kCommander's directory.
If lister.exe not exists, P2kCommander use notepad.exe to viewing files.
http://www.irfanview.com/
http://ghisler.com/tools.htm

Keyboard accelerators:

Tab: switch active panel (left/right)
Alt-F1 , Alt-F2 : drive select
Alt-R : Reread
Backspace: goto parentdir
F2: set file attributes (p2k filesystem)
F3: view file (using lister or if not found, notepad)
F4: edit with notepad
F5: copy
F7: create a directory
F8 , Del : delete a file
F9: restart p2k phone
F10: exit
Press starting letter to jump a file.